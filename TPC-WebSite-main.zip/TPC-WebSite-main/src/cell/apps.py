from django.apps import AppConfig


class CellConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'cell'
